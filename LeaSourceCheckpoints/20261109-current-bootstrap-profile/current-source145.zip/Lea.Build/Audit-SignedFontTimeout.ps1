$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$runRoot=Join-Path $root 'continuity-evidence/private-binding-full-owned-v4'
$out='I:\LeaBuildStorage\signed-font-full-timeout-audit-20261108-v1'
if(Test-Path $out){throw 'Preserve timeout audit'}
$receipt=Join-Path $runRoot 'result.json'
if((Get-FileHash $receipt).Hash -cne '6A1DAC82AC49B218F86944C100022330CD36D50C566400FC7575B5031F4774DF'){throw 'Timeout receipt identity differs'}
$r=Get-Content $receipt -Raw|ConvertFrom-Json
if($r.passed -or !$r.completed -or !$r.inputsUnchanged -or $r.ownerAttention -or $r.runs.Count -ne 1){throw 'Expected retained failed campaign'}
$run=$r.runs[0]
if(!$run.timedOut -or !$run.killRequested -or $run.parentBudgetMs -ne 300000 -or $run.exitCode -ne 57005 -or $run.activeAfterRetirement -ne 0 -or !$run.outputDrained -or !$run.stdoutComplete -or !$run.stderrComplete -or $run.sharedRetirementDrainBudgetMs -ne 5000 -or $run.retirementAndDrainElapsedMs -gt 5000){throw 'Original timeout/retirement boundary differs'}
foreach($input in $r.inputs){if((Get-FileHash $input.path).Hash -cne $input.sha256){throw 'Input changed after failure'}}
$deltas=@(foreach($file in $r.before){
    $hash=(Get-FileHash $file.path).Hash
    if($hash -cne $file.sha256){throw 'Runtime bytes changed'}
    $acl=(Get-Acl $file.path).Sddl
    if($acl -cne $file.sddl){@{path=$file.path;beforeSddl=$file.sddl;afterSddl=$acl}}
})
if($r.before.Count -ne 65 -or $deltas.Count -ne 1 -or [IO.Path]::GetFileName($deltas[0].path) -cne 'Lea.Image.exe' -or $r.changedFiles.Count -ne 1 -or $r.changedFiles[0] -cne $deltas[0].path -or !$r.traceActivationVerified -or $r.traceEnvironmentRestored){throw 'Quarantine conditions differ'}
function ReadPhases([string]$path){
    $starts=@{};$times=@{}
    foreach($line in Get-Content $path){
        if($line -cmatch '^LEA_SUITE_PHASE ([0-9]+) ([0-9]+) (begin|end)$'){
            $t=[int]$Matches[1];$n=[int]$Matches[2]
            if($Matches[3] -ceq 'begin'){$starts[$n]=$t}
            elseif($starts.ContainsKey($n)){$times[$n]=$t-$starts[$n]}
        }
    }
    return $times
}
$phases=@(Get-Content $run.stderr|Where-Object {$_ -cmatch '^LEA_SUITE_PHASE [0-9]+ [0-9]+ (begin|end)$'})
if($phases.Count -ne 141){throw 'Expected phases0..69 complete and70 begun'}
for($i=0;$i -lt 70;$i++){
    if($phases[2*$i] -cnotmatch ('^LEA_SUITE_PHASE [0-9]+ '+$i+' begin$') -or $phases[2*$i+1] -cnotmatch ('^LEA_SUITE_PHASE [0-9]+ '+$i+' end$')){throw 'Failure phase sequence differs'}
}
if($phases[140] -cnotmatch '^LEA_SUITE_PHASE [0-9]+ 70 begin$'){throw 'Failure location differs'}
$oldPath=Join-Path $root 'continuity-evidence/private-binding-full-owned-v3/full-script-timed.stderr.txt'
$old=ReadPhases $oldPath;$current=ReadPhases $run.stderr
$comparison=@(foreach($n in $current.Keys){@{phase=$n;historicalMs=$old[$n];currentMs=$current[$n];deltaMs=($current[$n]-$old[$n])}})
New-Item -ItemType Directory $out|Out-Null
$copies=@(foreach($path in $receipt,$run.stdout,$run.stderr,(Join-Path $runRoot 'full-script-timed.result.json')){
    $to=Join-Path $out ([IO.Path]::GetFileName($path));Copy-Item $path $to
    $hash=(Get-FileHash $path).Hash;if((Get-FileHash $to).Hash -cne $hash){throw 'Failure evidence copy differs'}
    @{path=$to;sha256=$hash}
})
@{failureCaptureVerified=$true;passed=$false;quarantined=$true;runtimeBytesUnchanged=$true;aclDeltas=$deltas;completedPhases=70;startedPhase=70;elapsedMs=$run.elapsedMs;retirementMs=$run.retirementAndDrainElapsedMs;workersRetired=$true;traceEnvironmentRestorationProven=$false;historicalTimingComparisonOnly=$comparison;causeProven=$false;hostAdopted=$false;copies=$copies;runnerSha256=(Get-FileHash $PSCommandPath).Hash}|ConvertTo-Json -Depth 7|Set-Content (Join-Path $out 'audit.json') -Encoding utf8
Get-FileHash (Join-Path $out 'audit.json')
