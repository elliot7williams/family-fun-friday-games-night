param([switch]$KeepForegroundHost,[ValidateRange(1,2)][int]$Version=1)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$recovery='I:\LeaBuildStorage\signed-suite-recovery-complete-20261108-v1'
$baseline=Join-Path $root 'continuity-evidence/private-binding-full-suite-v3'
$out=Join-Path $root ('continuity-evidence/signed-font-full-entry-v'+$Version)
if(!$KeepForegroundHost -or '-NoExit' -notin [Environment]::GetCommandLineArgs() -or [Console]::IsInputRedirected -or [Console]::IsOutputRedirected){throw 'Retained NoExit TTY required'}
if(([Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Nonadmin required'}
if((Get-PSDrive C).Free -lt 600MB -or (Test-Path $out) -or (Get-Variable LeaCompositeProcessLeases -Scope Global -ErrorAction SilentlyContinue)){throw 'Fresh owner/evidence and original reserve required'}
if(@(Get-Process 'Lea.Script.Tests','Lea.Script.Worker','Lea.Firespider.Boot','Firespider*' -ErrorAction SilentlyContinue).Count){throw 'No browser/test overlap'}
$global:LeaCompositeProcessLeases=[Collections.Generic.List[object]]::new()
$holds=[Collections.Generic.List[IDisposable]]::new()
$inputs=[Collections.Generic.List[object]]::new()
$runs=[Collections.Generic.List[object]]::new()
function Hold([string]$path,[string]$pin){
    $item=Get-Item -LiteralPath $path
    while($item){if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Reparse input refused'};$item=if($item -is [IO.FileInfo]){$item.Directory}else{$item.Parent}}
    $stream=[IO.File]::Open($path,'Open','Read','Read');$holds.Add($stream)
    $hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream))
    if($pin -and $hash -cne $pin){throw ('Entry input differs: '+$path)}
    $inputs.Add(@{path=$path;sha256=$hash})
}
New-Item -ItemType Directory -Path $out|Out-Null
$result=@{passed=$false;inputs=$inputs;runs=$runs;executed=$false;fullSuiteCompiled=$false;hostAdopted=$false;assertionsChanged=$false}
try{
    Hold $PSCommandPath;Copy-Item $PSCommandPath (Join-Path $out 'build.ps1')
    Hold (Join-Path $recovery 'assembly.json') 'C96375575C0453C295CAA2FD08185ABFFCCBD134C463E2E673ADB49F926975F9'
    Hold (Join-Path $recovery 'entry-result.json') '1D6568EAB3114AAABBBE403298085A6F6B33E1C02814C9B21CF0E4CAC5221CB6'
    $source=Join-Path $recovery 'WorkerEntryNativeHost.cs';Hold $source '28EF2916951EE0C5ABA9E30D39FF20549119898292AC2BDAF5FCFBA7D105EFB8'
    $copied=Join-Path $out 'WorkerEntryNativeHost.cs';Copy-Item $source $copied;Hold $copied '28EF2916951EE0C5ABA9E30D39FF20549119898292AC2BDAF5FCFBA7D105EFB8'
    $resource=Join-Path $recovery 'entry-fixture.json';Hold $resource '64C6F06B04EF62D6541A6E155943EA14C32824E41F5ADC3DE4D87A668FE4C046'
    $fixture=Get-Content $resource -Raw|ConvertFrom-Json -AsHashtable
    if($fixture.directory -cne (Join-Path $baseline 'runtime/WorkerEntryFixture') -or $fixture.files.Count -ne 7 -or $fixture.files['Lea.Script.Worker.dll'] -cne 'F61B6858822F8F7BB0350B91D21862C6D22EC955EE94E2E4F4060FA01FB344F0'){throw 'Original entry resource differs'}
    foreach($name in $fixture.files.Keys){if([IO.Path]::GetFileName($name) -cne $name){throw 'Unsafe fixture member'};Hold (Join-Path $fixture.directory $name) $fixture.files[$name]}
    $fixture.directory=Join-Path $root ('continuity-evidence/private-binding-full-suite-v'+(3+$Version)+'/runtime/WorkerEntryFixture')
    $resource=Join-Path $out 'entry-fixture.json';$fixture|ConvertTo-Json -Depth 5|Set-Content $resource -Encoding utf8;Hold $resource
    $owned=Join-Path $PSScriptRoot 'OwnedTestProcess.cs';Hold $owned 'D553F33A48B9B7DD5CF97012E6974C4B4054C315B19FD0086C05543844242AFA';Add-Type -Path $owned
    $helper=Join-Path $PSScriptRoot 'Invoke-OwnedTestRun.ps1';Hold $helper 'E5DD42C23546F58CEF425DE5602CC39D478409A824FDBB4C19F5CB454FC0FC00';. $helper
    $compiler='C:\Program Files\dotnet\dotnet.exe';Hold $compiler
    $toolchain='C:\Program Files\dotnet\sdk\8.0.427\Roslyn\bincore'
    foreach($name in 'csc.dll','csc.deps.json','csc.runtimeconfig.json','Microsoft.CodeAnalysis.dll','Microsoft.CodeAnalysis.CSharp.dll'){Hold (Join-Path $toolchain $name)}
    $exe=Join-Path $out 'WorkerEntryNativeHost.exe'
    $options=@('/nologo','/noconfig','/nostdlib+','/target:exe','/platform:x64','/langversion:12.0','/optimize+','/deterministic+','/warnaserror+',('/out:"'+$exe+'"'),('/resource:"'+$resource+'",Lea.EntryFixture.json'))
    $refs='C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8'
    foreach($name in 'mscorlib.dll','System.dll','System.Core.dll','System.Web.Extensions.dll'){$path=Join-Path $refs $name;Hold $path;$options+=('/reference:"'+$path+'"')}
    $options+=('"'+$copied+'"')
    $recipe=Join-Path $out 'entry.rsp';[IO.File]::WriteAllLines($recipe,$options,[Text.UTF8Encoding]::new($false));Hold $recipe
    $run=Invoke-OwnedTestRun -Name 'compile-signed-font-entry' -Application $compiler -Arguments @(('"'+(Join-Path $toolchain 'csc.dll')+'"'),('@"'+$recipe+'"')) -WorkingDirectory $out -OutputDirectory $out -Seconds 120 -Records $runs
    if(!$run.passed){throw 'Signed font entry compile failed'}
    Hold $exe
    $manifestPath=Join-Path $baseline 'runtime/WorkerEntryProbe/manifest.json';Hold $manifestPath '1F961E22D8BA537A0DCA83D5B8BA41B47DDBA628AAA9825ED319B7EEBFBE2CA5'
    $spec=Get-Content $manifestPath -Raw|ConvertFrom-Json -AsHashtable
    $spec.files['WorkerEntryNativeHost.exe']=(Get-FileHash $exe).Hash
    $spec.fixtureFiles=$fixture.files
    $manifest=Join-Path $out 'entry-manifest.json';$spec|ConvertTo-Json -Depth 5|Set-Content $manifest -Encoding utf8;Hold $manifest
    $result.outputs=@(foreach($path in $exe,$manifest,$resource){@{path=$path;sha256=(Get-FileHash $path).Hash}})
    $result.fixtureDirectory=$fixture.directory
    $result.passed=$true
}catch{$result.error=$_.Exception.ToString()}
finally{
    $result.inputsUnchanged=@($inputs|Where-Object {(Get-FileHash $_.path).Hash -cne $_.sha256}).Count -eq 0
    $result.ownerAttention=$global:LeaCompositeProcessLeases.Count -ne 0 -or [bool](Get-Variable LeaCompositeUnverifiedChild -Scope Global -ErrorAction SilentlyContinue)
    $result.passed=$result.passed -and $result.inputsUnchanged -and !$result.ownerAttention
    if(!$result.ownerAttention){foreach($hold in $holds){$hold.Dispose()}}else{$global:LeaSignedEntryInputLeases=$holds}
    $result|ConvertTo-Json -Depth 8|Set-Content (Join-Path $out 'result.json') -Encoding utf8
    $result|Select-Object passed,inputsUnchanged,ownerAttention,error|ConvertTo-Json
}
