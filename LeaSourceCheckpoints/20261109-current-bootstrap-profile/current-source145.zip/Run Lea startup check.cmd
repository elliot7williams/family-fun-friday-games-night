@echo off
setlocal
echo Lea isolated startup diagnostic - one run, unchanged candidate and limits.
echo Start this file by double-clicking it in File Explorer. Do not run as administrator.
echo Results are retained under continuity-evidence\bootstrap-numeric-stores-v1\cases.
"C:\Program Files\PowerShell\7\pwsh.exe" -NoLogo -NoProfile -NonInteractive -File "C:\Users\Elliot\Documents\Family Fun Friday Games Night copy\continuity-evidence\bootstrap-numeric-stores-v1\Run-NumericStoresChecks.explorer-v1.ps1" -ExpectedBuildReceiptSha256 A8BF14FE6903807E60B5E47FE10051F06440E864D33FAC7C8B89F7667A2F9ECF -ExpectedBuildScriptSha256 C03269B687F9C3FB581D036B2980870756724BCB2294D451069F88C7EC76EF1C -ExpectedRunnerScriptSha256 AE3F9D8B041E7C87CD98E562A71131EEC308DB753A2A4AB8C3F4FD4D3DE1E26F
set "LEA_DIAGNOSTIC_EXIT=%ERRORLEVEL%"
echo.
echo Finished with exit code %LEA_DIAGNOSTIC_EXIT%. A failure is useful evidence; do not rerun.
echo Return to the Lea Codex chat after this window says it finished.
pause
exit /b %LEA_DIAGNOSTIC_EXIT%
