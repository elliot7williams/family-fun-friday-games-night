using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web.Script.Serialization;

namespace Lea.Script
{
    internal static class Wire
    {
        private const int Magic = 0x5341454c;
        internal const int MaxFrame = 128 * 1024;
        internal const int Version = 3;
        private static readonly Encoding Utf8 = new UTF8Encoding(false, true);

        internal static Dictionary<string, object> Of(params object[] fields)
        {
            if (fields == null) throw new ArgumentNullException("fields");
            if (fields.Length < 2 || fields.Length > 16 || fields.Length % 2 != 0)
                throw new ArgumentException("A script frame requires one to eight key/value pairs.", "fields");
            var frame = new Dictionary<string, object>(fields.Length / 2, StringComparer.Ordinal);
            for (var index = 0; index < fields.Length; index += 2)
            {
                var key = fields[index] as string;
                if (key == null || key.Length != 1 || "kignfrbvsmdtpc".IndexOf(key[0]) < 0 || frame.ContainsKey(key))
                    throw new ArgumentException("Invalid or duplicate script frame key.", "fields");
                frame.Add(key, fields[index + 1]);
            }
            return frame;
        }

        internal static void Write(Stream stream, object value)
        {
            Send(stream, Pack(value));
        }

        internal sealed class H
        {
            private readonly byte[][] packets = new byte[3][];

            internal H(int guards, bool file)
            {
                if (guards < 0 || guards > 15) throw new ArgumentOutOfRangeException("guards");
                for (var network = 0; network < packets.Length; network++)
                    packets[network] = Pack(Of("k", "hello", "g", guards, "n", network, "f", file ? 1 : 0));
            }

            internal void Sr(Stream stream, int network)
            {
                if (network < 0 || network >= packets.Length) throw new InvalidDataException("Invalid hello network result.");
                Send(stream, packets[network]);
            }
        }

        internal static H Hi(int guards, bool file) { return new H(guards, file); }
        internal static void Hr(Stream stream, H hello, int network)
        {
            if (hello == null) throw new ArgumentNullException("hello");
            hello.Sr(stream, network);
        }

        private static byte[] Pack(object value)
        {
            try
            {
                var json = Serializer().Serialize(value);
                var length = Utf8.GetByteCount(json);
                if (length > MaxFrame) throw new InvalidDataException("Script frame is too large.");
                var packet = new byte[12 + length];
                Put(packet, 0, Magic);
                Put(packet, 4, Version);
                Put(packet, 8, length);
                Utf8.GetBytes(json, 0, json.Length, packet, 12);
                return packet;
            }
            catch (Exception error) when (error is ArgumentException || error is InvalidOperationException)
            { throw new InvalidDataException("Invalid outgoing script frame.", error); }
        }

        private static void Send(Stream stream, byte[] packet)
        {
            stream.Write(packet, 0, packet.Length);
            stream.Flush();
        }

        internal static Dictionary<string, object> Read(Stream stream)
        {
            var header = ReadBytes(stream, 12);
            var length = Get(header, 8);
            if (Get(header, 0) != Magic || Get(header, 4) != Version || length < 2 || length > MaxFrame)
                throw new InvalidDataException("Invalid script frame header.");
            try
            {
                var value = Serializer().DeserializeObject(Utf8.GetString(ReadBytes(stream, length))) as Dictionary<string, object>;
                if (value == null || value.Count > 8) throw new InvalidDataException("Invalid script frame object.");
                return value;
            }
            catch (Exception error) when (error is ArgumentException || error is InvalidOperationException)
            { throw new InvalidDataException("Invalid script frame JSON.", error); }
        }

        internal static void Fields(Dictionary<string, object> frame, params string[] names)
        {
            if (frame.Count != names.Length) throw new InvalidDataException("Unexpected script frame fields.");
            foreach (var name in names)
                if (!frame.ContainsKey(name)) throw new InvalidDataException("Missing script frame field.");
        }

        internal static string Step(Dictionary<string, object> frame, int execution, ref int request)
        {
            if (Number(frame, "i") != execution) throw new InvalidDataException("Unexpected script execution ID.");
            var kind = Text(frame, "k", 8);
            if (kind == "end")
            {
                Fields(frame, "k", "i", "s", "m", "d");
                var status = Text(frame, "s", 8);
                if (status != "ok" && status != "js" && status != "limit")
                    throw new InvalidDataException("Unexpected worker result.");
                Text(frame, "m", 512);
                if (!(frame["d"] is bool)) throw new InvalidDataException("Invalid event cancellation result.");
            }
            else
            {
                Fields(frame, "k", "i", "r", "b");
                if (kind != "call" || request >= 256 || Number(frame, "r") != request + 1 || !(frame["b"] is object[]))
                    throw new InvalidDataException("Invalid script request sequence or arguments.");
                request++;
            }
            return kind;
        }

        internal static string Text(Dictionary<string, object> frame, string key, int max)
        {
            object value;
            if (!frame.TryGetValue(key, out value) || !(value is string) || ((string)value).Length > max)
                throw new InvalidDataException("Invalid script frame string.");
            return (string)value;
        }

        internal static int Number(Dictionary<string, object> frame, string key)
        {
            object value;
            if (!frame.TryGetValue(key, out value) || !(value is int)) throw new InvalidDataException("Invalid script frame number.");
            return (int)value;
        }

        internal static double Time(Dictionary<string, object> frame)
        {
            object value;
            if (!frame.TryGetValue("t", out value) || !(value is int || value is long || value is double || value is decimal))
                throw new InvalidDataException("Invalid frame timestamp.");
            var time = Convert.ToDouble(value);
            if (Double.IsNaN(time) || Double.IsInfinity(time) || time < 0 || time > 9007199254740991)
                throw new InvalidDataException("Invalid frame timestamp.");
            return time;
        }

        internal static object[] Rk(Dictionary<string, object> frame)
        {
            object value;
            var keys = frame.TryGetValue("p", out value) ? value as object[] : null;
            if (keys == null || keys.Length < 1 || keys.Length > 64) throw new InvalidDataException("Invalid frame callbacks.");
            var previous = 0;
            foreach (var key in keys)
            {
                if (!(key is int) || (int)key <= previous) throw new InvalidDataException("Invalid frame handle order.");
                previous = (int)key;
            }
            return keys;
        }

        private static JavaScriptSerializer Serializer()
        { return new JavaScriptSerializer { MaxJsonLength = MaxFrame, RecursionLimit = 8 }; }

        private static byte[] ReadBytes(Stream stream, int length)
        {
            var bytes = new byte[length];
            var at = 0;
            while (at < bytes.Length)
            {
                var count = stream.Read(bytes, at, bytes.Length - at);
                if (count == 0) throw new EndOfStreamException("Script worker pipe ended.");
                at += count;
            }
            return bytes;
        }

        private static void Put(byte[] bytes, int at, int value)
        { for (var index = 0; index < 4; index++) bytes[at + index] = (byte)(value >> (index * 8)); }
        private static int Get(byte[] bytes, int at)
        { return bytes[at] | bytes[at + 1] << 8 | bytes[at + 2] << 16 | bytes[at + 3] << 24; }
    }
}
