using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32.SafeHandles;

namespace Lea.Win
{
    // Rp launches one restricted worker and owns its exact inherited pipes.
    internal sealed class Rp : IDisposable
    {
        private const uint Inherit = 0x00000001;
        private const uint Suspended = 0x00000004;
        private const uint NoWindow = 0x08000000;
        private const uint ExtendedStartup = 0x00080000;
        private const uint PersistentAcls = 0x00000008;
        private const long WorkerFileLimit = 16L * 1024 * 1024;
        private static readonly IntPtr HandleList = new IntPtr(0x00020002);
        private static readonly IntPtr MitigationPolicy = new IntPtr(0x00020007);
        private static readonly IntPtr SecurityCapabilities = new IntPtr(0x00020009);
        // DEP, SEHOP, heap termination, and force/bottom-up/high-entropy ASLR.
        private const long StartupPolicy = 0x00111105L;
        private const string ContainerName = "Lea.Image.Decoder";
        private const int AlreadyExists = unchecked((int)0x800700b7);
        private static readonly object portableGate = new object();
        private static readonly Dictionary<string, Tuple<string, string>> portable =
            new Dictionary<string, Tuple<string, string>>(StringComparer.OrdinalIgnoreCase);

        public Process P { get; private set; }
        public Stream I { get; private set; }
        public Stream O { get; private set; }
        public Jb J { get; private set; }
        public bool R { get; private set; }
        public bool L { get; private set; }
        public bool S { get; private set; }
        public bool A { get; private set; }
        public bool M { get; private set; }
        public bool C { get; private set; }
        public bool N { get; private set; }
        public bool F { get; private set; }
        public bool B { get; private set; }
        public string Sid { get; private set; }
        public bool Ready { get; set; }
        public int G { get; set; }

        internal string Lt { get; private set; } = "";

        private Stream error;
        private SafeProcessHandle processHandle;
        private Func<bool> release;
        private bool terminateOnDispose;
        private readonly object errorGate = new object();
        private readonly StringBuilder errorText = new StringBuilder();

        public string E { get { lock (errorGate) return errorText.ToString(); } }

        internal long? Ct
        {
            get
            {
                var handle = processHandle;
                if (handle == null || handle.IsClosed || handle.IsInvalid) return null;
                long created, exited, kernel, user;
                try
                {
                    if (!GetProcessTimes(handle, out created, out exited, out kernel, out user) ||
                        kernel < 0 || user < 0 || kernel > Int64.MaxValue - user) return null;
                    return (kernel + user) / TimeSpan.TicksPerMillisecond;
                }
                catch (ObjectDisposedException) { return null; }
            }
        }

        private Rp(Process process, Stream input, Stream output, Stream errors, Jb job, bool restricted,
            bool low, bool container, bool noCapabilities, bool fileAcl)
        {
            P = process;
            I = input;
            O = output;
            error = errors;
            J = job;
            R = restricted;
            L = low;
            S = true;
            A = true;
            M = true;
            C = container;
            N = noCapabilities;
            F = fileAcl;
            Task.Factory.StartNew(() => Drain(errors), default(System.Threading.CancellationToken),
                TaskCreationOptions.LongRunning, TaskScheduler.Default);
        }

        internal static string Prepare(string path)
        {
            var full = Path.GetFullPath(path);
            if (!System.IO.File.Exists(full) || HasPersistentAcls(full)) return full;
            lock (portableGate)
            {
                Tuple<string, string> cached;
                if (portable.TryGetValue(full, out cached) && System.IO.File.Exists(cached.Item1) &&
                    Digest(cached.Item1).Equals(cached.Item2, StringComparison.OrdinalIgnoreCase)) return cached.Item1;
                var source = new FileInfo(full);
                if (source.Length < 1 || source.Length > WorkerFileLimit)
                    throw new InvalidDataException("Lea image worker exceeds the portable staging limit.");
                var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                if (String.IsNullOrWhiteSpace(local)) local = Path.GetTempPath();
                var directory = Path.Combine(local, "Lea", "Image");
                Directory.CreateDirectory(directory);
                if (!HasPersistentAcls(directory))
                    throw new NotSupportedException("Lea image isolation requires an ACL-capable local cache.");
                var digest = Digest(full);
                var target = Path.Combine(directory, "Lea.Image-" + digest + ".exe");
                if (!System.IO.File.Exists(target) || !Digest(target).Equals(digest, StringComparison.OrdinalIgnoreCase))
                {
                    if (System.IO.File.Exists(target)) System.IO.File.Delete(target);
                    var temporary = target + "." + Guid.NewGuid().ToString("N") + ".tmp";
                    try
                    {
                        System.IO.File.Copy(full, temporary, false);
                        if (!Digest(temporary).Equals(digest, StringComparison.OrdinalIgnoreCase))
                            throw new InvalidDataException("Lea image worker changed during portable staging.");
                        try { System.IO.File.Move(temporary, target); }
                        catch (IOException)
                        {
                            if (!System.IO.File.Exists(target) || !Digest(target).Equals(digest, StringComparison.OrdinalIgnoreCase)) throw;
                        }
                    }
                    finally { if (System.IO.File.Exists(temporary)) System.IO.File.Delete(temporary); }
                }
                portable[full] = Tuple.Create(target, digest);
                return target;
            }
        }

        public static Rp Open(string path, string args, string directory, long memory, int cpu)
        {
            return Open(path, args, directory, memory, cpu, ContainerName, new[] { path }, false);
        }

        internal static Rp Open(string path, string args, string directory, long memory, int cpu,
            string profile, IList<string> files, bool temporaryProfile)
        {
            if (memory <= 0 || (IntPtr.Size == 4 && memory > UInt32.MaxValue))
                throw new ArgumentOutOfRangeException("memory");
            if (cpu < 100 || cpu > 10000) throw new ArgumentOutOfRangeException("cpu");

            // Opt-in diagnostic timestamps only; no I/O, security or deadline changes.
            var launchClock = Environment.GetEnvironmentVariable("LEA_SCRIPT_STARTUP_TRACE") == "1" ? Stopwatch.StartNew() : null;
            var launchTrace = launchClock == null ? null : new StringBuilder("native{");
            Action<string> note = label =>
            {
                if (launchTrace != null) launchTrace.Append(label).Append('=').Append(launchClock.ElapsedMilliseconds).Append(';');
            };
            IntPtr attributes = IntPtr.Zero;
            IntPtr handles = IntPtr.Zero;
            IntPtr mitigation = IntPtr.Zero;
            IntPtr appSid = IntPtr.Zero;
            IntPtr capabilities = IntPtr.Zero;
            IntPtr childInput = IntPtr.Zero;
            IntPtr parentInput = IntPtr.Zero;
            IntPtr parentOutput = IntPtr.Zero;
            IntPtr childOutput = IntPtr.Zero;
            IntPtr parentError = IntPtr.Zero;
            IntPtr childError = IntPtr.Zero;
            var info = new ProcessInfo();
            var created = false;
            Process process = null;
            SafeProcessHandle retained = null;
            FileStream input = null;
            FileStream output = null;
            FileStream errors = null;
            Jb job = null;
            SecurityIdentifier identity = null;
            try
            {
                if (temporaryProfile)
                    foreach (var file in files)
                        if (!HasPersistentAcls(file) || GetDriveType(Path.GetPathRoot(Path.GetFullPath(file))) == 4)
                            throw new NotSupportedException("Worker isolation requires an ACL-capable local volume.");
                note("volume");
                appSid = ContainerSid(profile);
                note("profile");
                identity = new SecurityIdentifier(appSid);
                if (temporaryProfile && !NoLoopback(appSid))
                    throw new InvalidOperationException("Script-worker AppContainer has a loopback exemption.");
                note("loopback");
                var fileAcl = true;
                foreach (var file in files) fileAcl &= GrantFile(file, appSid);
                if (!fileAcl) throw new InvalidOperationException("Worker file access was not applied.");

                note("grants");
                var security = new SecurityAttributes { Length = Marshal.SizeOf(typeof(SecurityAttributes)), Inherit = true };
                Pipe(ref security, out childInput, out parentInput, true);
                Pipe(ref security, out parentOutput, out childOutput, false);
                Pipe(ref security, out parentError, out childError, false);

                note("pipes");
                IntPtr attributeSize = IntPtr.Zero;
                InitializeProcThreadAttributeList(IntPtr.Zero, 3, 0, ref attributeSize);
                if (attributeSize == IntPtr.Zero) throw Error("Lea could not size its worker handle list.");
                attributes = Marshal.AllocHGlobal(attributeSize);
                if (!InitializeProcThreadAttributeList(attributes, 3, 0, ref attributeSize))
                    throw Error("Lea could not create its worker handle list.");
                handles = Marshal.AllocHGlobal(IntPtr.Size * 3);
                Marshal.WriteIntPtr(handles, 0, childInput);
                Marshal.WriteIntPtr(handles, IntPtr.Size, childOutput);
                Marshal.WriteIntPtr(handles, IntPtr.Size * 2, childError);
                if (!UpdateProcThreadAttribute(attributes, 0, HandleList, handles, new IntPtr(IntPtr.Size * 3),
                    IntPtr.Zero, IntPtr.Zero)) throw Error("Lea could not restrict inherited worker handles.");
                mitigation = Marshal.AllocHGlobal(8);
                Marshal.WriteInt64(mitigation, StartupPolicy);
                if (!UpdateProcThreadAttribute(attributes, 0, MitigationPolicy, mitigation, new IntPtr(8),
                    IntPtr.Zero, IntPtr.Zero)) throw Error("Lea could not set image-worker startup mitigations.");
                var emptyCapabilities = new CapabilitySet { AppContainerSid = appSid };
                capabilities = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(CapabilitySet)));
                Marshal.StructureToPtr(emptyCapabilities, capabilities, false);
                if (!UpdateProcThreadAttribute(attributes, 0, SecurityCapabilities, capabilities,
                    new IntPtr(Marshal.SizeOf(typeof(CapabilitySet))), IntPtr.Zero, IntPtr.Zero))
                    throw Error("Lea could not set image-worker security capabilities.");

                note("attributes");
                var startup = new StartupInfoEx();
                startup.Startup.Length = Marshal.SizeOf(typeof(StartupInfoEx));
                startup.Startup.Flags = 0x00000100;
                startup.Startup.StandardInput = childInput;
                startup.Startup.StandardOutput = childOutput;
                startup.Startup.StandardError = childError;
                startup.Attributes = attributes;
                var command = new StringBuilder("\"" + path.Replace("\"", "") + "\"" +
                    (String.IsNullOrWhiteSpace(args) ? "" : " " + args));
                if (!CreateProcessAsUser(IntPtr.Zero, path, command, IntPtr.Zero, IntPtr.Zero, true,
                    Suspended | NoWindow | ExtendedStartup, IntPtr.Zero, directory, ref startup, out info))
                    throw Error("Lea could not start its restricted image worker.");
                note("create");
                created = true;
                bool noCapabilities;
                bool restricted;
                bool low;
                if (!AppContainer(info.Process, appSid, out noCapabilities, out restricted, out low) ||
                    !noCapabilities || !restricted || !low)
                    throw new InvalidOperationException("Lea image worker did not enter its restricted zero-capability AppContainer.");
                note("token");
                var aslr = Aslr(info.Process);
                if ((aslr & 3) != 3)
                    throw new InvalidOperationException("Lea image-worker startup ASLR was not applied: policy=" + aslr + ".");
                Close(ref childInput);
                Close(ref childOutput);
                Close(ref childError);

                note("aslr-pipes");
                job = Jb.Add(info.Process, memory, cpu);
                note("job");
                input = File(parentInput, FileAccess.Write);
                parentInput = IntPtr.Zero;
                output = File(parentOutput, FileAccess.Read);
                parentOutput = IntPtr.Zero;
                errors = File(parentError, FileAccess.Read);
                parentError = IntPtr.Zero;
                process = Process.GetProcessById(info.ProcessId);
                if (ResumeThread(info.Thread) == UInt32.MaxValue) throw Error("Lea could not resume its bounded image worker.");
                Close(ref info.Thread);
                note("resume");
                // Retain the exact native identity for counters even after the child exits.
                retained = new SafeProcessHandle(info.Process, true);
                info.Process = IntPtr.Zero;
                var worker = new Rp(process, input, output, errors, job, restricted, low, true, noCapabilities, fileAcl);
                worker.processHandle = retained;
                worker.Sid = identity.Value;
                worker.B = temporaryProfile;
                if (temporaryProfile) worker.release = () => Release(profile, files, identity);
                note("return");
                worker.Lt = launchTrace == null ? "" : launchTrace.Append('}').ToString();
                return worker;
            }
            catch (Exception error)
            {
                if (temporaryProfile && identity != null)
                {
                    var failed = new Rp(process, input, output, errors ?? Stream.Null, job, false, false, true, true, false);
                    failed.processHandle = retained;
                    if (failed.processHandle == null && created && info.Process != IntPtr.Zero)
                    {
                        failed.processHandle = new SafeProcessHandle(info.Process, true);
                        info.Process = IntPtr.Zero;
                    }
                    failed.terminateOnDispose = created && job == null;
                    failed.Sid = identity.Value;
                    failed.B = true;
                    failed.release = () => Release(profile, files, identity);
                    try { failed.Dispose(); }
                    catch (Exception cleanup) when (cleanup is IOException || cleanup is UnauthorizedAccessException ||
                        cleanup is InvalidOperationException || cleanup is Win32Exception || cleanup is System.Security.SecurityException)
                    { throw new SetupFailure(new AggregateException(error, cleanup), failed); }
                    if (failed.P != null || failed.processHandle != null || failed.CleanupPending)
                        throw new SetupFailure(error, failed);
                    throw;
                }
                if (job != null) job.Dispose();
                else if (created && info.Process != IntPtr.Zero) TerminateProcess(info.Process, 1);
                if (process != null) process.Dispose();
                if (retained != null) retained.Dispose();
                if (input != null) input.Dispose();
                if (output != null) output.Dispose();
                if (errors != null) errors.Dispose();
                if (temporaryProfile && identity != null) Release(profile, files, identity);
                throw;
            }
            finally
            {
                Close(ref info.Thread);
                Close(ref info.Process);
                Close(ref childInput);
                Close(ref parentInput);
                Close(ref parentOutput);
                Close(ref childOutput);
                Close(ref parentError);
                Close(ref childError);
                if (attributes != IntPtr.Zero) { DeleteProcThreadAttributeList(attributes); Marshal.FreeHGlobal(attributes); }
                if (handles != IntPtr.Zero) Marshal.FreeHGlobal(handles);
                if (mitigation != IntPtr.Zero) Marshal.FreeHGlobal(mitigation);
                if (capabilities != IntPtr.Zero) Marshal.FreeHGlobal(capabilities);
                if (appSid != IntPtr.Zero) FreeSid(appSid);
            }
        }

        public void Dispose()
        {
            // Kill first so a blocked reader on an inherited pipe can finish.
            if (J != null) J.Dispose();
            else if (terminateOnDispose && processHandle != null && !processHandle.IsClosed && !processHandle.IsInvalid)
            {
                try { TerminateRetained(processHandle, 1); }
                catch (ObjectDisposedException) { return; }
            }
            if (I != null) try { I.Dispose(); } catch (IOException) { }
            if (O != null) try { O.Dispose(); } catch (IOException) { }
            if (error != null) try { error.Dispose(); } catch (IOException) { }
            if (processHandle != null)
            {
                try
                {
                    if (processHandle.IsClosed || processHandle.IsInvalid ||
                        WaitForSingleObject(processHandle, 1000) != 0) return;
                }
                catch (ObjectDisposedException) { return; }
            }
            else if (P != null)
            {
                bool exited;
                try { exited = P.WaitForExit(1000); }
                catch (InvalidOperationException) { exited = false; }
                if (!exited) return;
            }
            if (P != null) P.Dispose();
            if (processHandle != null) processHandle.Dispose();
            processHandle = null;
            I = null;
            O = null;
            error = null;
            J = null;
            P = null;
            var cleanup = release;
            if (cleanup != null && cleanup()) release = null;
        }

        internal sealed class SetupFailure : InvalidOperationException
        {
            internal Rp Endpoint { get; private set; }
            internal SetupFailure(Exception cause, Rp endpoint)
                : base("Worker setup failed; cleanup remains pending. " + cause.Message, cause)
            { Endpoint = endpoint; }
        }

        [DllImport("kernel32.dll", EntryPoint = "TerminateProcess", SetLastError = true)]
        private static extern bool TerminateRetained(SafeProcessHandle process, uint exitCode);

        internal bool CleanupPending { get { return release != null; } }

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern uint WaitForSingleObject(SafeProcessHandle process, uint milliseconds);

        internal static bool Release(string profile, IList<string> files, SecurityIdentifier identity)
        {
            var revoked = true;
            foreach (var file in files)
                try
                {
                    if (!FileAccessRule(file, identity, false)) revoked = false;
                }
                catch (IOException) { revoked = false; }
                catch (UnauthorizedAccessException) { revoked = false; }
            // Keep the profile recoverable while any file grant remains unverified.
            return revoked && DeleteAppContainerProfile(profile) == 0;
        }

        private void Drain(Stream stream)
        {
            var buffer = new char[1024];
            try
            {
                using (var reader = new StreamReader(stream, new UTF8Encoding(false), false, 1024, true))
                {
                    int count;
                    while ((count = reader.Read(buffer, 0, buffer.Length)) > 0)
                        lock (errorGate)
                        {
                            var remove = errorText.Length + count - buffer.Length;
                            if (remove > 0) errorText.Remove(0, remove);
                            errorText.Append(buffer, 0, count);
                        }
                }
            }
            catch (IOException) { }
            catch (ObjectDisposedException) { }
        }

        private static FileStream File(IntPtr handle, FileAccess access)
        {
            return new FileStream(new SafeFileHandle(handle, true), access, 4096, false);
        }

        private static void Pipe(ref SecurityAttributes security, out IntPtr read, out IntPtr write, bool parentWrites)
        {
            if (!CreatePipe(out read, out write, ref security, 0)) throw Error("Lea could not create an image-worker pipe.");
            var parent = parentWrites ? write : read;
            if (!SetHandleInformation(parent, Inherit, 0)) throw Error("Lea could not restrict an image-worker pipe.");
        }

        private static IntPtr TokenInfo(IntPtr token, int kind)
        {
            uint size = 0;
            GetTokenInformation(token, kind, IntPtr.Zero, 0, out size);
            if (size == 0) throw Error("Lea could not size image-worker token data.");
            var data = Marshal.AllocHGlobal((int)size);
            if (!GetTokenInformation(token, kind, data, size, out size))
            {
                Marshal.FreeHGlobal(data);
                throw Error("Lea could not read image-worker token data.");
            }
            return data;
        }

        private static int Integrity(IntPtr token)
        {
            var data = TokenInfo(token, 25);
            try
            {
                var sid = Marshal.PtrToStructure<SidAttribute>(data).Sid;
                var count = Marshal.ReadByte(GetSidSubAuthorityCount(sid));
                return count == 0 ? Int32.MaxValue : Marshal.ReadInt32(GetSidSubAuthority(sid, count - 1));
            }
            finally { Marshal.FreeHGlobal(data); }
        }

        private static bool PrivilegesStripped(IntPtr token)
        {
            var data = TokenInfo(token, 3);
            try
            {
                var count = Marshal.ReadInt32(data);
                var enabled = 0;
                for (var index = 0; index < count; index++)
                    if ((Marshal.ReadInt32(data, 4 + index * 12 + 8) & 2) != 0) enabled++;
                return enabled <= 1;
            }
            finally { Marshal.FreeHGlobal(data); }
        }

        private static bool AppContainer(IntPtr process, IntPtr expectedSid, out bool noCapabilities,
            out bool restricted, out bool low)
        {
            noCapabilities = false;
            restricted = false;
            low = false;
            IntPtr token;
            if (!OpenProcessToken(process, 0x0008, out token)) throw Error("Lea could not inspect its image-worker token.");
            try
            {
                var state = TokenInfo(token, 29);
                var identity = IntPtr.Zero;
                var groups = IntPtr.Zero;
                try
                {
                    if (Marshal.ReadInt32(state) == 0) return false;
                    identity = TokenInfo(token, 31);
                    var sid = Marshal.ReadIntPtr(identity);
                    if (sid == IntPtr.Zero || !EqualSid(sid, expectedSid)) return false;
                    groups = TokenInfo(token, 30);
                    noCapabilities = Marshal.ReadInt32(groups) == 0;
                    restricted = PrivilegesStripped(token);
                    low = Integrity(token) == 4096;
                    return true;
                }
                finally
                {
                    Marshal.FreeHGlobal(state);
                    if (identity != IntPtr.Zero) Marshal.FreeHGlobal(identity);
                    if (groups != IntPtr.Zero) Marshal.FreeHGlobal(groups);
                }
            }
            finally { Close(ref token); }
        }

        private static bool GrantFile(string path, IntPtr appSid)
        { return FileAccessRule(path, new SecurityIdentifier(appSid), true); }

        internal static bool FileAccessRule(string path, SecurityIdentifier identity, bool grant)
        {
            string name;
            using (var sha = SHA256.Create())
                name = "Global\\Lea.FileAcl." + BitConverter.ToString(sha.ComputeHash(
                    Encoding.UTF8.GetBytes(Path.GetFullPath(path).ToUpperInvariant()))).Replace("-", "");
            // Coordinate read/modify/write across tabs, linked launcher assemblies, and host processes.
            Mutex mutex;
            try { mutex = new Mutex(false, name); }
            catch (WaitHandleCannotBeOpenedException error)
            { throw new IOException("Worker permission synchronization is unavailable.", error); }
            using (mutex)
            {
                var held = false;
                try
                {
                    try { held = mutex.WaitOne(1000); }
                    catch (AbandonedMutexException) { held = true; }
                    if (!held) throw new IOException("Worker file permission update is busy.");
                    var rights = FileSystemRights.ReadAndExecute | FileSystemRights.Synchronize;
                    var security = System.IO.File.GetAccessControl(path, AccessControlSections.Access);
                    var exact = false;
                    var other = false;
                    foreach (FileSystemAccessRule rule in security.GetAccessRules(true, true, typeof(SecurityIdentifier)))
                    {
                        if (!identity.Equals(rule.IdentityReference)) continue;
                        if (rule.AccessControlType == AccessControlType.Allow)
                        {
                            if (ExactFileGrant(rule, rights)) exact = true;
                            else other = true;
                        }
                        else if (grant) return false;
                    }
                    if (grant)
                    {
                        // An inherited or broader grant cannot establish an owned, revocable file lease.
                        if (other) return false;
                        if (exact) return true;
                        security.AddAccessRule(new FileSystemAccessRule(identity, rights, AccessControlType.Allow));
                    }
                    else
                    {
                        if (!exact) return !other;
                        security.RemoveAccessRuleSpecific(new FileSystemAccessRule(identity, rights, AccessControlType.Allow));
                    }
                    System.IO.File.SetAccessControl(path, security);
                    security = System.IO.File.GetAccessControl(path, AccessControlSections.Access);
                    var found = false;
                    foreach (FileSystemAccessRule rule in security.GetAccessRules(true, true, typeof(SecurityIdentifier)))
                    {
                        if (!identity.Equals(rule.IdentityReference)) continue;
                        if (rule.AccessControlType == AccessControlType.Allow)
                        {
                            if (!grant || !ExactFileGrant(rule, rights)) return false;
                            found = true;
                        }
                        else if (grant) return false;
                    }
                    return !grant || found;
                }
                finally { if (held) mutex.ReleaseMutex(); }
            }
        }

        private static bool ExactFileGrant(FileSystemAccessRule rule, FileSystemRights rights)
        {
            return rule.FileSystemRights == rights && !rule.IsInherited &&
                rule.InheritanceFlags == InheritanceFlags.None && rule.PropagationFlags == PropagationFlags.None;
        }

        private static bool NoLoopback(IntPtr expectedSid)
        {
            uint count;
            IntPtr items;
            var code = NetworkIsolationGetAppContainerConfig(out count, out items);
            try
            {
                if (code != 0) throw new Win32Exception((int)code, "Lea could not inspect loopback exemptions.");
                var size = Marshal.SizeOf(typeof(SidAttribute));
                for (var index = 0; index < count; index++)
                {
                    var item = Marshal.PtrToStructure<SidAttribute>(IntPtr.Add(items, index * size));
                    if (EqualSid(item.Sid, expectedSid)) return false;
                }
                return true;
            }
            finally
            {
                if (items != IntPtr.Zero)
                {
                    var heap = GetProcessHeap();
                    var size = Marshal.SizeOf(typeof(SidAttribute));
                    for (var index = 0; index < count; index++)
                        HeapFree(heap, 0, Marshal.PtrToStructure<SidAttribute>(IntPtr.Add(items, index * size)).Sid);
                    HeapFree(heap, 0, items);
                }
            }
        }

        private static bool HasPersistentAcls(string path)
        {
            try
            {
                var root = Path.GetPathRoot(Path.GetFullPath(path));
                uint serial;
                uint component;
                uint flags;
                return !String.IsNullOrEmpty(root) && GetVolumeInformation(root, null, 0, out serial,
                    out component, out flags, null, 0) && (flags & PersistentAcls) != 0;
            }
            catch (Exception) { return false; }
        }

        private static string Digest(string path)
        {
            byte[] value;
            using (var algorithm = SHA256.Create())
            using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                value = algorithm.ComputeHash(stream);
            var text = new StringBuilder(value.Length * 2);
            foreach (var item in value) text.Append(item.ToString("x2"));
            return text.ToString();
        }

        private static uint Aslr(IntPtr process)
        {
            uint policy;
            if (!GetProcessMitigationPolicy(process, 1, out policy, new UIntPtr(4)))
                throw Error("Lea could not verify image-worker startup ASLR.");
            return policy;
        }

        private static IntPtr ContainerSid(string name)
        {
            IntPtr sid;
            var result = CreateAppContainerProfile(name, name, name,
                IntPtr.Zero, 0, out sid);
            if (result == 0) return sid;
            if (result == AlreadyExists)
            {
                result = DeriveAppContainerSidFromAppContainerName(name, out sid);
                if (result == 0) return sid;
            }
            ProfileResult(result);
            throw new InvalidOperationException("Lea could not create its image-worker AppContainer profile.");
        }

        internal static void ProfileResult(int result)
        {
            try { Marshal.ThrowExceptionForHR(result); }
            catch (COMException error)
            {
                throw new IOException("Lea could not create its worker AppContainer profile (0x" +
                    result.ToString("X8") + "). " + error.Message, error);
            }
        }

        private static void Close(ref IntPtr handle)
        {
            var value = handle;
            handle = IntPtr.Zero;
            if (value != IntPtr.Zero && value != new IntPtr(-1)) CloseHandle(value);
        }

        private static Win32Exception Error(string message)
        {
            return new Win32Exception(Marshal.GetLastWin32Error(), message);
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct SidAttribute { public IntPtr Sid; public uint Attributes; }

        [StructLayout(LayoutKind.Sequential)]
        private struct CapabilitySet
        {
            public IntPtr AppContainerSid;
            public IntPtr Capabilities;
            public uint CapabilityCount;
            public uint Reserved;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct SecurityAttributes
        {
            public int Length;
            public IntPtr SecurityDescriptor;
            [MarshalAs(UnmanagedType.Bool)] public bool Inherit;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct StartupInfo
        {
            public int Length;
            public string Reserved;
            public string Desktop;
            public string Title;
            public int X;
            public int Y;
            public int XSize;
            public int YSize;
            public int XChars;
            public int YChars;
            public int Fill;
            public int Flags;
            public short Show;
            public short ReservedBytes;
            public IntPtr ReservedData;
            public IntPtr StandardInput;
            public IntPtr StandardOutput;
            public IntPtr StandardError;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct StartupInfoEx { public StartupInfo Startup; public IntPtr Attributes; }

        [StructLayout(LayoutKind.Sequential)]
        private struct ProcessInfo
        {
            public IntPtr Process;
            public IntPtr Thread;
            public int ProcessId;
            public int ThreadId;
        }

        [DllImport("advapi32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool OpenProcessToken(IntPtr process, uint access, out IntPtr token);
        [DllImport("advapi32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetTokenInformation(IntPtr token, int kind, IntPtr data, uint length, out uint needed);
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "CreateProcessAsUserW")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CreateProcessAsUser(IntPtr token, string application, StringBuilder command,
            IntPtr processAttributes, IntPtr threadAttributes, [MarshalAs(UnmanagedType.Bool)] bool inherit,
            uint flags, IntPtr environment, string directory, ref StartupInfoEx startup, out ProcessInfo info);
        [DllImport("userenv.dll", CharSet = CharSet.Unicode)]
        private static extern int DeriveAppContainerSidFromAppContainerName(string name, out IntPtr sid);
        [DllImport("userenv.dll", CharSet = CharSet.Unicode)]
        private static extern int CreateAppContainerProfile(string name, string displayName, string description,
            IntPtr capabilities, uint capabilityCount, out IntPtr sid);

        [DllImport("userenv.dll", CharSet = CharSet.Unicode)]
        private static extern int DeleteAppContainerProfile(string name);
        [DllImport("advapi32.dll")] private static extern IntPtr FreeSid(IntPtr sid);
        [DllImport("advapi32.dll")] [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool EqualSid(IntPtr first, IntPtr second);
        [DllImport("advapi32.dll")] private static extern IntPtr GetSidSubAuthorityCount(IntPtr sid);
        [DllImport("advapi32.dll")] private static extern IntPtr GetSidSubAuthority(IntPtr sid, int index);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CreatePipe(out IntPtr read, out IntPtr write, ref SecurityAttributes security, uint size);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetHandleInformation(IntPtr handle, uint mask, uint flags);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool InitializeProcThreadAttributeList(IntPtr list, int count, int flags, ref IntPtr size);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool UpdateProcThreadAttribute(IntPtr list, uint flags, IntPtr attribute, IntPtr value,
            IntPtr size, IntPtr previous, IntPtr returned);
        [DllImport("kernel32.dll")] private static extern void DeleteProcThreadAttributeList(IntPtr list);
        [DllImport("kernel32.dll", SetLastError = true)] private static extern uint ResumeThread(IntPtr thread);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetProcessMitigationPolicy(IntPtr process, int kind, out uint policy, UIntPtr length);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetVolumeInformation(string root, StringBuilder volumeName, uint volumeNameSize,
            out uint serial, out uint maximumComponentLength, out uint fileSystemFlags,
            StringBuilder fileSystemName, uint fileSystemNameSize);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        private static extern uint GetDriveType(string root);
        [DllImport("Firewallapi.dll")]
        private static extern uint NetworkIsolationGetAppContainerConfig(out uint count, out IntPtr sids);
        [DllImport("kernel32.dll")] private static extern IntPtr GetProcessHeap();
        [DllImport("kernel32.dll")] [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool HeapFree(IntPtr heap, uint flags, IntPtr memory);
        [DllImport("kernel32.dll")] [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool TerminateProcess(IntPtr process, uint exitCode);
        [DllImport("kernel32.dll")] [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetProcessTimes(SafeProcessHandle process, out long created, out long exited,
            out long kernel, out long user);
        [DllImport("kernel32.dll")] [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CloseHandle(IntPtr value);
    }
}
